package com.afollestad.appthemeengine.inflation;

/**
 * @author Aidan Follestad (afollestad)
 */
public interface ViewInterface {

    boolean setsStatusBarColor();

    boolean setsToolbarColor();
}