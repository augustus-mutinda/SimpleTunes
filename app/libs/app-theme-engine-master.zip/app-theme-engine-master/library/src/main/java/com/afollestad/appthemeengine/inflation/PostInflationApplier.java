package com.afollestad.appthemeengine.inflation;

/**
 * @author Aidan Follestad (afollestad)
 */
public interface PostInflationApplier {

    void postApply();
}